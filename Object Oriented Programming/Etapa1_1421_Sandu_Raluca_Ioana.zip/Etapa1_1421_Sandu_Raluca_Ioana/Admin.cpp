#include "Admin.hpp"

#include <iostream>
#include <string.h>
using namespace std;

long Admin::numarAdmini=0;

Admin::Admin(const Admin& administrator):idAdmin(administrator.idAdmin)
{
    this->parola=administrator.parola;
}
Admin::Admin():idAdmin(numarAdmini++)
{
    this->parola="default";
}
Admin::Admin(string parola):idAdmin(numarAdmini)
{
    this->parola=parola;
    numarAdmini++;
}
istream& operator>>(istream& in, Admin& a)
{
    cout<<"Parola: ";
    in>>a.parola;
    return in;
}
ostream& operator<<(ostream& out, const Admin& a)
{
    out<<"{ID admin: "<<a.idAdmin<<", Parola: "<<a.parola << "}";
    return out;
}
// seteaza parola adminului curent la parola altui admin
Admin& Admin::operator=(const Admin& administrator)
{
    if(this!=&administrator)
    {
        this->parola=administrator.parola;
    }
    return *this;
}
string Admin::getParola()
{
    return this->parola;
}
void Admin::setParola(string parola)
{
    this->parola=parola;
}
bool Admin::verificaParola(string parolaDeVerificat)
{
    return parola == parolaDeVerificat;
}
Admin::~Admin()
{
}
