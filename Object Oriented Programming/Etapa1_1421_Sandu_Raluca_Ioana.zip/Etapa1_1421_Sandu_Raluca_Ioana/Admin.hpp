#ifndef ADMIN_HPP_INCLUDED
#define ADMIN_HPP_INCLUDED

#include <iostream>
#include <string.h>
using namespace std;

class Admin
{
private:
    const int idAdmin;
    string parola;
public:
    static long numarAdmini;

//Constructorul de copiere:
    Admin(const Admin& administrator);
//Constructorul fara parametri:
    Admin();
//Constructorul cu parametri:
    Admin(string parola);
//Operatorul egal:
    Admin& operator=(const Admin& administrator);
//Operatorul << :
    friend ostream& operator<<(ostream& out, const Admin& a);
//Operatorul >>:
    friend istream& operator>>(istream& in, Admin& a);
//setter si getter pentru parola
    string getParola();
    void setParola(string parola);
///Functionalitate: metoda care testeaza daca parola introdusa de la tastatura corespunde cu parola adminului
    bool verificaParola(string parolaDeVerificat);
//Destructorul:
    ~Admin();
};
#endif // ADMIN_HPP_INCLUDED
