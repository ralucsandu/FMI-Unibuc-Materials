#include <iostream>

#include "Utilizator.hpp"
#include "Imprumut.hpp"
#include "Tranzactie.hpp"
#include "Cont.hpp"
#include "Admin.hpp"


using namespace std;

void test_utilizator()
{
    /*char c[]= {"Sandu"};
    char c2[]= {"Dima"};
    char c3[]= {"Popescu"};
    int* conturi=new int[2];
    conturi[0]=1234;
    conturi[1]=1235;
    int conturi2[]= {1233, 1234, 1235, 1236};
    string date[4]= {"0748259400", "ralu_ioana_99@yahoo.com", "Str. Berlin", "Nr. 13"};
    string date1[4]= {"0336805571", "raluca.sandu5@s.unibuc.ro", "Drumul Timonierului", "Nr. 8"};
    Utilizator z(c3, "Elena", true, 12378.3, 0.3, 'A', "6010421150028", 3050.5, 4, conturi2, date1, 20.0);
    Utilizator u(c,"Raluca",false, 0, 0,'C', "6010400029600",2300.0,2,conturi,date, 23);
    Utilizator b("Popescu", "Ana", 'C', "601040029300", date1);
    Utilizator u1;
    u1=u;
    cout<<Utilizator::NumarUtilizatori<<"\n";
    cout<<z.getNume()<<"\n";
    u.setNume(c2);

    cout<<u.getNume()<<"\n";
    cout<<u.getImpozit()<<"\n";
    cout<<u.getNrConturi()<<"\n";
/*
    int* cont=u.getConturi();
    cout<<*cont;
    for (int i=0; i<u.getNrConturi(); i++)
    cout<<*(u.getConturi()+i)<<"\n";
    for (int i=0; i<4; i++)
    cout<<*(u.getDatePersonale()+i)<<"\n";

    u.setConturi(conturi2,4);
    u.setPrenume("Adi");
    cout<<u.getPrenume()<<"\n";
    for (int i=0; i<u.getNrConturi(); i++)
    cout<<*(u.getConturi()+i)<<"\n";
    //u.citire();
    //u.afisare();
*/
    Utilizator z;
    Utilizator x;
    //cout<<"\n";
    cin>>x;
    //cout<<x.inCateLuniSeVaPuteaRestituiImprumutul()<<"\n";
    cout<<"\n";
    cout<<x;
    //cout<<u;
    cout<<"\n";
    cin>>z;
    //cout<<z;
    if(x.inCateLuniSeVaPuteaRestituiImprumutul()==1)
        cout<<"Utilizatorul isi va putea restitui imprumutul intr-o luna";
    else if (x.inCateLuniSeVaPuteaRestituiImprumutul()==0)
        cout<<"Utilizatorul nu are imprumuturi";
    else
        cout<<"Utilizatorul isi va putea restitui imprumutul in " << x.inCateLuniSeVaPuteaRestituiImprumutul()<< " luni";
    cout<<"\n";
    Utilizator test;
    cout<<(x>=z);
    //test=z-555;
    //cout<<test.getSalariuMediu();

}

void test_imprumut()
{
    /*Imprumut imp(3495.59, 1234);
    cout<<imp.getIdCont()<<"\n";
    cout<<"Valoarea initiala a imprumutului(in lei) este de: "<<imp.getValoareImprumut()<<"\n";
    imp.setValoareImprumut(200.45);
    cout<<"Valoarea imprumutului(in lei) dupa folosirea setter-ului este de: "<<imp.getValoareImprumut();
    Imprumut impr;
    cin>>impr;
    cout<<"\n";
    cout<<impr;*/

    // 5 ani, 9 luni, 3 zile
    Imprumut j(1204.89, 1119);
    Imprumut i("5,9,3", 234.5);
    cout<<i.getDurata() << "\n";
    --i;
    cout<<i.getDurata() << "\n";
    cout<<i.CandTrebuieReturnat();
    cout<<"\n";

    cout<<"Valoarea imprumutului ca numar intreg este "<<(int)j<<" lei";
}

void test_cont()
{
    Cont c(1234,98);
    cout<<c.getIDutilizator()<<"\n";
    float sold[1]= {1293.0};
    Cont x(sold, "lei");
    cout<<x.getSoldCurent()<<"\n";
    cout<<"Valuta initiala este: "<<x.getValuta()<<"\n";
    x.setValuta("lire");
    cout<<"Valuta dupa folosirea setter-ului este: "<<x.getValuta();
    cout<<"\n";
    x.schimbValuta();
    cout<<"\n";

    //Cont x;
    //cin>>x;
    /*cout<<x-20;
    cout<<x+20;*/
    /*cout<<x;
    cout<<"\n";
    Cont y;
    cin>>y;
    x=y;
    cout<<"\n";
    cout<<x;*/
}

void test_admin()
{
    Admin aux;
    Admin x;
    Admin y;
    string parola = "";
    cout << "Citim parola primului admin:"<<"\n";
    cin>>x;
    cout << "x = " << x << "\n";
    cout<<"Parola curenta este: "<<x.getParola()<<"\n";
    x.setParola("245g");
    cout<<"Parola dupa folosirea setter-ului ar fi: "<< x.getParola();
    cout<<"\n";
    cout<<"\n";
    cout << "Citim parola celui de-al doilea admin:"<<"\n";
    cin >> y;
    cout << "y = " << y << "\n";
    cout<<"\n";
    cout << "Schimbam parola lui x astfel incat sa fie aceeasi cu a lui y"<<"\n";
    cout<<"\n";
    aux = x;
    x=y;
    cout << "x ar trebui sa fie de forma " << x << "\n";
    cout<<"\n";
    cout << "Introduceti noua parola a lui x: ";
    cin >> parola;
    if (x.verificaParola(parola)!=0)
        cout << "Parola introdusa este corecta";
    else
        cout << "Parola introdusa este gresita";
    cout<<"\n";

    cout<<Admin::numarAdmini;
}

void test_tranzactie()
{
    //Tranzactie t(256.4, 12345, "01.04.2001");
    //Tranzactie u(891.5, 23456, "02.06.1920");
    Tranzactie t(259.4, "01.03.2021", 1110, 2220, 123456);
    Tranzactie u(256.4, "20.03.2021", 1111, 2222, 123456);
    t.setIDcontCarePrimeste(219);
    t.setIDcontCareTrimite(300);
    cout<<t.getValoareTranzactie();
    cout<<"\n";
    cout<<t.getDataTranzactie();
    cout<<"\n";
    cout<< t.convertToString();
    cout<<"\n";
    Tranzactie raspuns;
    raspuns = 100.2+ t;
    cout<<raspuns.getValoareTranzactie();
    cout<<"\n";
    Cont c;
    /*cout<<c.GetNumarTranzactii();
    c=c+t;
    cout<<c.GetNumarTranzactii();
    cout<<"\n";
    c=c+raspuns;
    cout<<c.GetNumarTranzactii();*/
    c=c+t;
    c=u+c;
    c.ParcurgereTranzactie();
    cout<<"\n";
    //cout<<(t==u);
    Tranzactie aux;
    int index=1;
    if (c[index]==aux)
        cout<<"Tranzactia nu exista";
    else
        cout<<c[index];
    cout<<"\n";
    cout<<"\n";
    Tranzactie x;
    cin>>x;
    cout<<"\n";
    cout<<x;
}
int main()
{

    //test_utilizator();
    //test_imprumut();
    //test_cont();
    test_admin();
    //test_tranzactie();
    return 0;
}
